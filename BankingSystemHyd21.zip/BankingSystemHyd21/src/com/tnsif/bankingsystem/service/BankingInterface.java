package com.tnsif.bankingsystem.service;

import java.util.Collection;

import com.tnsif.bankingsystem.entity.Customer;

public interface BankingInterface {
	
	
	public void addCustomer(Customer customer);
	
	//get only customer based on id
	Customer findCustomerByID(int id);
	
	//get all customers details 
	Collection<Customer> getAllCustomers();
	
	
	
	
	

}
