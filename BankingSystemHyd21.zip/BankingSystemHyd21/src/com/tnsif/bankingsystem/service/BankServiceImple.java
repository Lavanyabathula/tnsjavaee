package com.tnsif.bankingsystem.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.tnsif.bankingsystem.entity.Customer;

public class BankServiceImple implements BankingInterface{
	
	private Map<Integer,Customer> customers=new HashMap();
	
	

	@Override
	public void addCustomer(Customer customer) {
       
		customers.put(customer.getCustomerID(),customer);
		
	}

	@Override
	public Customer findCustomerByID(int id) {

		return null;
	}

	@Override
	public Collection<Customer> getAllCustomers() {

		return null;
	}

}
