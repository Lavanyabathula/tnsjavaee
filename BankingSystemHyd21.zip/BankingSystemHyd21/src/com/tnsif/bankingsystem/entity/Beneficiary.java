package com.tnsif.bankingsystem.entity;

public class Beneficiary {

}
