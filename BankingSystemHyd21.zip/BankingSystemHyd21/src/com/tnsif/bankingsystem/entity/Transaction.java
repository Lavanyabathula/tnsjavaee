package com.tnsif.bankingsystem.entity;

public class Transaction {

}
