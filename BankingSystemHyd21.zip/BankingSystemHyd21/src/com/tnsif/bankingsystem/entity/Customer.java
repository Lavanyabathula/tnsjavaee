package com.tnsif.bankingsystem.entity;

public class Customer {
	
	//instance variables
	private int customerID;
	private String name;
	private String contact;
	private String address;
	
	//constructor
	public Customer(int customerID, String name, String contact, String address) {
		super();
		this.customerID = customerID;
		this.name = name;
		this.contact = contact;
		this.address = address;
	}

	//getters and setters
	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", name=" + name + ", contact=" + contact + ", address=" + address
				+ "]";
	}

}
