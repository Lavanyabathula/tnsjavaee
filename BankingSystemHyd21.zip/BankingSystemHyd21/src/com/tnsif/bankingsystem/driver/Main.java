package com.tnsif.bankingsystem.driver;

import java.util.Scanner;

import com.tnsif.bankingsystem.entity.Customer;
import com.tnsif.bankingsystem.service.BankServiceImple;

public class Main {

	public static void main(String[] args) {


		BankServiceImple bs=new BankServiceImple();
		
		int customerID;
		String name;
		String address;
		String contact;
		
		int ch;
		Scanner sc=new Scanner(System.in);
		
		do {
			System.out.println("Welcome to BankingApplication, "
					+ "Kindly choose anyone of the option from below list");
			System.out.println("1.Add customer");
			System.out.println("2.Get Customer by ID");
			System.out.println("3.Get all customer details");
			System.out.println("4.Exit");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("Enter customer details");
				System.out.println("Enter customer id");
				customerID=sc.nextInt();
				System.out.println("Enter customer name");
				name=sc.nextLine();
				System.out.println("Enter customer contact");
				contact=sc.nextLine();
				System.out.println("Enter customer address");
				address=sc.nextLine();
				Customer c=new Customer(customerID,name,contact,address);
				bs.addCustomer(c);
				break;
				
				
				
			}
		}while((ch!=5));
		
		
		
		
		
		
		
		
		
	}

}
